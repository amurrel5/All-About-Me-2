//
//  All_About_Me_2App.swift
//  All About Me 2
//
//  Created by scholar on 4/22/23.
//

import SwiftUI

@main
struct All_About_Me_2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
